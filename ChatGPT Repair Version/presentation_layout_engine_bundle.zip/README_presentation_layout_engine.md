# Presentation Layout Engine — integration bundle

## What is included
- `presentation_layout_engine.py`: 60-layout catalogue, LLM recommendation, layout-aware content structuring, editable PowerPoint rendering, and PNG preview generation.
- `user_context_layouts_updated.py`: updated version of the supplied Gradio UI, with a template screenshot gallery, per-slide layout dropdown, and a **Generate slide (PPTX + screenshot)** action.
- `comfyui_updated.py`: fixes the supplied ComfyUI client so the composed `comfyui_prompts(...)` prompt is actually sent to ComfyUI. The uploaded version constructed `system_prompt` but passed only `slide_content`.
- `presentation_layout_library_updated.py`: 60-slide editable specimen-deck source.
- `presentation_layout_library_60.pptx`: updated editable 60-layout specimen deck.
- `presentation_layout_catalog_60.md`: descriptions for all 60 layouts.
- `layout_previews/`: 60 PNG thumbnails used by the Gradio template gallery.
- `layout_template_contact_sheet.png`: contact sheet for quickly reviewing the catalogue.

## Installation
Install the Python packages in the same virtual environment used by Gradio:
```bash
pip install python-pptx pillow
```
The updated UI still depends on the rest of your existing project modules (`imp_functions.py`, `tools_dec.py`, and `gemini_code_fixed.py`), which were referenced by your uploaded `user_context.py` but were not included in this upload set. Keep those modules in your project.

## Integration steps
1. Copy `presentation_layout_engine.py` into the same project folder as `user_context.py`.
2. Merge/replace the supplied UI with `user_context_layouts_updated.py` after backing up your current file. Rename it to `user_context.py` only once you've checked the imports and project paths.
3. Copy `comfyui_updated.py` over your current `comfyui.py` after backing it up. Keep `workflow_api_z_image.json` and ComfyUI running at `http://127.0.0.1:8188`.
4. Start the app using the same Python interpreter / virtual environment that has Gradio, `openai`, `python-pptx`, and Pillow installed.

## How it works
- The template gallery shows screenshots for the 60 layout archetypes. At app startup, thumbnails use the current first-slide artwork if `image_path_for(0)` returns an existing image. Otherwise it uses a clean sample background. Regenerate the gallery after creating artwork if you want all thumbnails to reflect the current artwork.
- Every slide gets a layout dropdown. `AUTO — LLM recommendation` asks the local OpenAI-compatible model to choose a layout; selecting a named layout manually overrides that recommendation.
- Clicking **Generate slide (PPTX + screenshot)** asks the LLM to restructure the slide content for the selected layout, creates an editable `slide_N.pptx`, and refreshes `slide_N_current.png` in the project root. The screenshot is also returned to the Gradio image preview.
- Per-slide PowerPoints and rendering intermediates are written under `presentation_output/`.
- Exact PowerPoint screenshots are produced when LibreOffice (`soffice`) and `pdftoppm` are installed and available on PATH. Otherwise the engine creates a Pillow preview from the same content/layout model; it is a useful preview but not a pixel-exact render of PowerPoint.
- The background image is treated as artwork only. Text, tables, cards, and diagrams are native editable PowerPoint objects. ComfyUI is not asked to render slide text.

## Important implementation notes
- The existing `gemini_code_fixed.py` is not included in the upload, so the UI continues to use its existing functions for session management and full-deck compilation. The new button independently generates a per-slide PPTX and preview.
- The uploaded `comfyui.py` was returning a filename prefix rather than the final image path. Existing `image_path_for(...)` is still used to locate the artwork, so keep its naming convention consistent with ComfyUI output (for example `slide_1_0.png`).
- The layout list is a broad reusable catalogue, not an exhaustive enumeration of every possible slide design. The 16 new entries cover executive summary, single idea, three-act story, milestone gates, capability map, value chain, operating model, service blueprint, product lifecycle, market segmentation, competitive positioning, opportunity prioritization, scenario planning, assumptions/hypotheses, implementation plan, and decision/approval.
